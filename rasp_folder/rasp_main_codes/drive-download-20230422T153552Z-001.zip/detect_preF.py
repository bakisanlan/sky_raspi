def detect_preF(candidate_px):
    if candidate_px != None:
        if candidate_px[0] != None:
            return candidate_px